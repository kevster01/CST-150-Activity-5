﻿namespace Activity_5
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.SelectFile_Lbl = new System.Windows.Forms.Label();
            this.LowerCase_Lbl = new System.Windows.Forms.Label();
            this.FirstWord_Lbl = new System.Windows.Forms.Label();
            this.LastWord_Lbl = new System.Windows.Forms.Label();
            this.LongestWord_Lbl = new System.Windows.Forms.Label();
            this.SaveFile_Lbl = new System.Windows.Forms.Label();
            this.btnSelect = new System.Windows.Forms.Button();
            this.text_Display = new System.Windows.Forms.RichTextBox();
            this.text_firstword = new System.Windows.Forms.TextBox();
            this.text_LastWord = new System.Windows.Forms.TextBox();
            this.text_LongestWord = new System.Windows.Forms.TextBox();
            this.VowelWord_Text = new System.Windows.Forms.TextBox();
            this.LongestVowel_Lbl = new System.Windows.Forms.Label();
            this.SelectFile_btn = new System.Windows.Forms.Button();
            this.Response_Text = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // SelectFile_Lbl
            // 
            this.SelectFile_Lbl.AutoSize = true;
            this.SelectFile_Lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SelectFile_Lbl.Location = new System.Drawing.Point(121, 118);
            this.SelectFile_Lbl.Name = "SelectFile_Lbl";
            this.SelectFile_Lbl.Size = new System.Drawing.Size(140, 29);
            this.SelectFile_Lbl.TabIndex = 0;
            this.SelectFile_Lbl.Text = "Select File: ";
            this.SelectFile_Lbl.Click += new System.EventHandler(this.label1_Click);
            // 
            // LowerCase_Lbl
            // 
            this.LowerCase_Lbl.AutoSize = true;
            this.LowerCase_Lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LowerCase_Lbl.Location = new System.Drawing.Point(121, 214);
            this.LowerCase_Lbl.Name = "LowerCase_Lbl";
            this.LowerCase_Lbl.Size = new System.Drawing.Size(220, 29);
            this.LowerCase_Lbl.TabIndex = 0;
            this.LowerCase_Lbl.Text = "Text in Lower Case";
            this.LowerCase_Lbl.Click += new System.EventHandler(this.label1_Click);
            // 
            // FirstWord_Lbl
            // 
            this.FirstWord_Lbl.AutoSize = true;
            this.FirstWord_Lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FirstWord_Lbl.Location = new System.Drawing.Point(121, 329);
            this.FirstWord_Lbl.Name = "FirstWord_Lbl";
            this.FirstWord_Lbl.Size = new System.Drawing.Size(124, 29);
            this.FirstWord_Lbl.TabIndex = 0;
            this.FirstWord_Lbl.Text = "First Word";
            this.FirstWord_Lbl.Click += new System.EventHandler(this.label1_Click);
            // 
            // LastWord_Lbl
            // 
            this.LastWord_Lbl.AutoSize = true;
            this.LastWord_Lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LastWord_Lbl.Location = new System.Drawing.Point(121, 401);
            this.LastWord_Lbl.Name = "LastWord_Lbl";
            this.LastWord_Lbl.Size = new System.Drawing.Size(121, 29);
            this.LastWord_Lbl.TabIndex = 0;
            this.LastWord_Lbl.Text = "Last Word";
            this.LastWord_Lbl.Click += new System.EventHandler(this.label1_Click);
            // 
            // LongestWord_Lbl
            // 
            this.LongestWord_Lbl.AutoSize = true;
            this.LongestWord_Lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LongestWord_Lbl.Location = new System.Drawing.Point(118, 485);
            this.LongestWord_Lbl.Name = "LongestWord_Lbl";
            this.LongestWord_Lbl.Size = new System.Drawing.Size(163, 29);
            this.LongestWord_Lbl.TabIndex = 0;
            this.LongestWord_Lbl.Text = "Longest Word";
            this.LongestWord_Lbl.Click += new System.EventHandler(this.label1_Click);
            // 
            // SaveFile_Lbl
            // 
            this.SaveFile_Lbl.AutoSize = true;
            this.SaveFile_Lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SaveFile_Lbl.Location = new System.Drawing.Point(164, 696);
            this.SaveFile_Lbl.Name = "SaveFile_Lbl";
            this.SaveFile_Lbl.Size = new System.Drawing.Size(177, 58);
            this.SaveFile_Lbl.TabIndex = 0;
            this.SaveFile_Lbl.Text = "Input and Save \r\n   To Text File\r\n";
            this.SaveFile_Lbl.Click += new System.EventHandler(this.label1_Click);
            // 
            // btnSelect
            // 
            this.btnSelect.Location = new System.Drawing.Point(492, 109);
            this.btnSelect.Name = "btnSelect";
            this.btnSelect.Size = new System.Drawing.Size(376, 38);
            this.btnSelect.TabIndex = 1;
            this.btnSelect.Text = "Open";
            this.btnSelect.UseVisualStyleBackColor = true;
            this.btnSelect.Click += new System.EventHandler(this.btnSelect_Click);
            // 
            // text_Display
            // 
            this.text_Display.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.text_Display.Location = new System.Drawing.Point(492, 199);
            this.text_Display.Name = "text_Display";
            this.text_Display.Size = new System.Drawing.Size(376, 62);
            this.text_Display.TabIndex = 2;
            this.text_Display.Text = "";
            // 
            // text_firstword
            // 
            this.text_firstword.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.text_firstword.Location = new System.Drawing.Point(492, 328);
            this.text_firstword.Name = "text_firstword";
            this.text_firstword.Size = new System.Drawing.Size(376, 30);
            this.text_firstword.TabIndex = 3;
            // 
            // text_LastWord
            // 
            this.text_LastWord.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.text_LastWord.Location = new System.Drawing.Point(492, 401);
            this.text_LastWord.Name = "text_LastWord";
            this.text_LastWord.Size = new System.Drawing.Size(376, 30);
            this.text_LastWord.TabIndex = 3;
            // 
            // text_LongestWord
            // 
            this.text_LongestWord.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.text_LongestWord.Location = new System.Drawing.Point(492, 475);
            this.text_LongestWord.Name = "text_LongestWord";
            this.text_LongestWord.Size = new System.Drawing.Size(376, 30);
            this.text_LongestWord.TabIndex = 3;
            // 
            // VowelWord_Text
            // 
            this.VowelWord_Text.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.VowelWord_Text.Location = new System.Drawing.Point(492, 536);
            this.VowelWord_Text.Name = "VowelWord_Text";
            this.VowelWord_Text.Size = new System.Drawing.Size(376, 30);
            this.VowelWord_Text.TabIndex = 3;
            // 
            // LongestVowel_Lbl
            // 
            this.LongestVowel_Lbl.AutoSize = true;
            this.LongestVowel_Lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LongestVowel_Lbl.Location = new System.Drawing.Point(121, 537);
            this.LongestVowel_Lbl.Name = "LongestVowel_Lbl";
            this.LongestVowel_Lbl.Size = new System.Drawing.Size(236, 29);
            this.LongestVowel_Lbl.TabIndex = 0;
            this.LongestVowel_Lbl.Text = "Longest Vowel Word";
            this.LongestVowel_Lbl.Click += new System.EventHandler(this.label1_Click);
            // 
            // SelectFile_btn
            // 
            this.SelectFile_btn.Location = new System.Drawing.Point(123, 764);
            this.SelectFile_btn.Name = "SelectFile_btn";
            this.SelectFile_btn.Size = new System.Drawing.Size(264, 32);
            this.SelectFile_btn.TabIndex = 4;
            this.SelectFile_btn.Text = "Create FIle";
            this.SelectFile_btn.UseVisualStyleBackColor = true;
            this.SelectFile_btn.Click += new System.EventHandler(this.SelectFile_btn_Click);
            // 
            // Response_Text
            // 
            this.Response_Text.Location = new System.Drawing.Point(492, 700);
            this.Response_Text.Name = "Response_Text";
            this.Response_Text.Size = new System.Drawing.Size(376, 96);
            this.Response_Text.TabIndex = 5;
            this.Response_Text.Text = "";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(976, 927);
            this.Controls.Add(this.Response_Text);
            this.Controls.Add(this.SelectFile_btn);
            this.Controls.Add(this.VowelWord_Text);
            this.Controls.Add(this.text_LongestWord);
            this.Controls.Add(this.text_LastWord);
            this.Controls.Add(this.text_firstword);
            this.Controls.Add(this.text_Display);
            this.Controls.Add(this.btnSelect);
            this.Controls.Add(this.SaveFile_Lbl);
            this.Controls.Add(this.LongestVowel_Lbl);
            this.Controls.Add(this.LongestWord_Lbl);
            this.Controls.Add(this.LastWord_Lbl);
            this.Controls.Add(this.FirstWord_Lbl);
            this.Controls.Add(this.LowerCase_Lbl);
            this.Controls.Add(this.SelectFile_Lbl);
            this.Name = "Form1";
            this.Text = " ";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label SelectFile_Lbl;
        private System.Windows.Forms.Label LowerCase_Lbl;
        private System.Windows.Forms.Label FirstWord_Lbl;
        private System.Windows.Forms.Label LastWord_Lbl;
        private System.Windows.Forms.Label LongestWord_Lbl;
        private System.Windows.Forms.Label SaveFile_Lbl;
        private System.Windows.Forms.Button btnSelect;
        private System.Windows.Forms.RichTextBox text_Display;
        private System.Windows.Forms.TextBox text_firstword;
        private System.Windows.Forms.TextBox text_LastWord;
        private System.Windows.Forms.TextBox text_LongestWord;
        private System.Windows.Forms.TextBox VowelWord_Text;
        private System.Windows.Forms.Label LongestVowel_Lbl;
        private System.Windows.Forms.Button SelectFile_btn;
        private System.Windows.Forms.RichTextBox Response_Text;
    }
}

