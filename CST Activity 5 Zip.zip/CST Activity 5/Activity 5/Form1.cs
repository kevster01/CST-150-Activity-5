﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Activity_5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        String str;
        String wtf;
        

        private void label1_Click(object sender, EventArgs e)
        {

        }

        int max_val = 0, max_index = 0, vow_count = 0, vow_index;

        private void SelectFile_btn_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "Text Files (.txt) |*.txt";
            if(saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                StreamWriter txt = new StreamWriter(saveFileDialog.FileName);
                txt.Write(Response_Text.Text);
                txt.Close();
            }

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnSelect_Click(object sender, EventArgs e)
        {

            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Text Documents | *.txt";
            //first condition
            if (ofd.ShowDialog() == DialogResult.OK)
            {
                //first condition
                str = System.IO.File.ReadAllText(ofd.FileName);
                text_Display.Text = str.ToLower();

                //second condition
                string[] wordText = str.Split(' ');
                Array.Sort(wordText);


                text_firstword.Text = wordText[0];
                text_LastWord.Text = wordText[wordText.Length - 1];
                //MessageBox.Show(text_LastWord.Text);

                //third condition
                for (int i = 0; i < wordText.Length - 1; i++)
                {
                    if (max_val < wordText[i].Length)
                    {
                        max_val = wordText[i].Length;
                        max_index = i;
                    }
                    if (vow_count < VowelCount(wordText[i]))
                    {
                        vow_count = VowelCount(wordText[i]);
                        vow_index = i;
                    }
                }
                
                text_LongestWord.Text = wordText[max_index];
                VowelWord_Text.Text=wordText[vow_index];
            }
        }

        public int VowelCount(string sentence)
        {
            int vowels = 0;
            for (int i = 0; i < sentence.Length - 1; i++)
            {
              if (
                   (sentence[i] == 'a' || sentence[i] == 'e' || sentence[i] == 'i' || sentence[i] == 'o' 
                   || sentence[i] == 'u') || (sentence[i] == 'A' || sentence[i] == 'E' || sentence[i] ==
                   'I' || sentence[i] == 'O' || sentence[i] == 'U')
                  )
              {
                  vowels = vowels + 1;
              }
            }
                return vowels;
            }
    }
}
